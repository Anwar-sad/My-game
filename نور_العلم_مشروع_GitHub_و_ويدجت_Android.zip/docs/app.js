'use strict';
(() => {
  const BANK=window.NOOR_QUESTIONS||[];
  const META=window.NOOR_META||{categories:[],total:0};
  const CAT=Object.fromEntries(META.categories.map(x=>[x.id,x]));
  const LS_SETTINGS='noor-settings-v3';
  const LS_PROGRESS='noor-progress-v3';
  const LS_SEEN='noor-seen-v3';
  const LS_LAST='noor-lastgroups-v3';
  const POINTS=[100,200,300,500,1000,2000,4000,8000,16000,32000,64000,125000,250000,500000,1000000];
  const LABELS=['أ','ب','ج','د'];
  const KINDS={study:'سؤال تعليمي',review:'سؤال مراجعة',comparison:'سؤال مقارنة'};
  const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>Number(n||0).toLocaleString('ar-MA');
  const read=(k,fallback)=>{try{const r=localStorage.getItem(k);return r?JSON.parse(r):fallback}catch{return fallback}};
  const write=(k,obj)=>{try{localStorage.setItem(k,JSON.stringify(obj))}catch{}};
  const defaultSettings={enabled:META.categories.map(c=>c.id),minDifficulty:3,comparisons:false,avoidRepeats:true};
  let settings={...defaultSettings,...read(LS_SETTINGS,{})};
  settings.enabled=(Array.isArray(settings.enabled)&&settings.enabled.length?settings.enabled:defaultSettings.enabled).filter(x=>CAT[x]);
  let progress={total:0,correct:0,wrong:0,best:0,byCat:{},bookmarks:[],mistakes:[],history:[] ,...read(LS_PROGRESS,{})};
  let seen=read(LS_SEEN,[]), lastGroups=read(LS_LAST,[]);
  const state={view:'home',session:null,selected:null,chosen:null,eliminated:[],search:'',searchScope:'all',installPrompt:null,toast:''};
  let savedScroll=0;
  const app=document.getElementById('app');
  if(!app)return;
  const choiceCat=id=>CAT[id]?.title||'علوم إسلامية';
  const header=()=>`<header class="topbar"><div class="wrap top-inner"><div class="brand" data-action="home" role="button" tabindex="0"><div class="brand-logo" aria-hidden="true">✦</div><div><strong>نور العلم</strong><small>رحلة في المعرفة الإسلامية</small></div></div><nav class="desktop-nav" aria-label="التنقل الرئيسي">${[['home','الرئيسية'],['quiz','التعلّم'],['challenge','التحدّي'],['saved','المحفوظات'],['settings','الإعدادات']].map(([a,n])=>`<button class="navbtn ${((state.view==='quiz'&&a==='quiz')||(state.view==='finished'&&a==='challenge')||(state.view===a))?'active':''}" data-action="${a==='quiz'?'start-learn':a==='challenge'?'start-challenge':a}">${n}</button>`).join('')}</nav><div class="head-actions"><button class="headbtn" data-action="search">⌕ بحث</button></div></div></header>`;
  const tabs=()=>`<nav class="mobile-tabs" aria-label="القائمة السفلية">${[['home','⌂','الرئيسية'],['quiz','▣','تعلّم'],['challenge','◆','التحدّي'],['saved','♡','المحفوظة'],['settings','⚙','الإعدادات']].map(([a,i,n])=>`<button class="${state.view===a?'active':''}" data-action="${a==='quiz'?'start-learn':a==='challenge'?'start-challenge':a}"><span>${i}</span>${n}</button>`).join('')}</nav>`;
  const footer=()=>`<footer class="footer wrap">نور العلم — مشروع تعليمي مجاني. بعض الأسئلة صياغات متنوّعة للوقائع نفسها، والمعلومات التاريخية مميّزة عن النصوص الشرعية.<br>المحتوى خضع لفحوص اتساق تقنية، وليس لمراجعة شرعية مستقلة لكل سؤال.</footer>`;
  const stats=()=>`<div class="stats"><div class="stat"><strong>${fmt(META.total)}</strong><small>صيغة سؤال في البنك</small></div><div class="stat"><strong>${fmt(progress.total)}</strong><small>إجاباتك المسجلة</small></div><div class="stat"><strong>${fmt(progress.correct)}</strong><small>إجابات صحيحة</small></div><div class="stat"><strong>${fmt(progress.best)}</strong><small>أفضل تحدٍّ بالنقاط</small></div></div>`;
  const catCard=c=>`<article class="cat"><div class="cat-head"><div class="cat-icon" aria-hidden="true">${({names:'✧',prophets:'☼',family:'❖',companions:'★',seerah:'✦',quran:'☷',tafsir:'◈',battles:'⚑',hadith:'♡'})[c.id]}</div><div><b>${escape(c.title)}</b><small>${fmt(c.count)} صيغة سؤال</small></div></div><p>${escape(c.description)}</p><div class="cat-end"><span class="chip">${fmt(progress.byCat?.[c.id]?.correct||0)} إجابة صحيحة</span><button class="mini-btn" data-action="start-cat" data-cat="${c.id}">ابدأ القسم ←</button></div></article>`;
  const home=()=>`<div class="intro-grid"><section class="hero"><span class="eyebrow">✦ اختبر معرفتك وتعلّم بالدليل</span><h1>كلّ سؤال يقودك<br>إلى <em>علمٍ أعمق</em></h1><p>أسئلة جادّة في القرآن والسيرة والأنبياء وأهل البيت والصحابة وغير ذلك. اختر الأقسام التي تريد، ثم اقرأ تفسير الإجابة ودليلها — سواء أصبت أم أخطأت.</p><div class="actions"><button class="btn primary" data-action="start-learn">ابدأ التعلّم الحر ⟵</button><button class="btn secondary" data-action="start-challenge">تحدٍّ من 15 سؤالًا</button></div></section><aside class="hero-side"><div><span class="side-kicker">استعدّ لسؤال اليوم</span><h2>التعلّم عادة يومية، لا مجرد نقاط.</h2><p>في نسخة أندرويد المرفقة بالمشروع توجد أداة تفاعلية للشاشة الرئيسية؛ وفي نسخة الويب تستطيع تثبيت الموقع كتطبيق.</p></div><div class="mini-question">✦ بعد كل إجابة: الجواب الصحيح، شرح المعنى، سبب خطأ البدائل، ورابط المرجع.</div><div class="side-foot">● بنك أسئلة مدمج للعمل دون إنترنت</div></aside></div>${stats()}<div class="section-head"><div><h2>اختر مجال المعرفة</h2><p>افتح قسمًا بعينه، أو حدد عدة أقسام في الإعدادات للتعلّم المختلط.</p></div><span class="mini">${META.categories.length} أقسام تعليمية</span></div><div class="cats">${META.categories.map(catCard).join('')}</div><div class="info-strip"><b>حول التوثيق:</b> نستخدم روابط الآيات والأحاديث، ونميّز الأخبار المنقولة من كتب السيرة. قسم «معاني الآيات» يشرح دلالة النص ولا يدّعي أنه نقل حرفي عن مفسر بعينه. ${fmt(META.total)} هو عدد صيغ الأسئلة، لا عدد الوقائع المستقلة.</div>`;
  const srcBadge=q=>({quran:'القرآن الكريم',hadith:'حديث نبوي',history:'كتب السيرة والتاريخ'})[q.source?.kind]||'مرجع';
  const sourceBox=q=>{const x=q.source||{};return `<div class="proof"><strong>المصدر • ${escape(srcBadge(q))}</strong><div>${escape(x.label||'مصدر مذكور')}</div>${x.text?`<blockquote>${escape(x.text)}</blockquote>`:''}${/^https:\/\//.test(x.url||'')?`<a href="${escape(x.url)}" target="_blank" rel="noopener noreferrer">فتح المرجع للتحقق وقراءة السياق ↗</a>`:''}</div>`};
  const opts=q=>q.options.map((o,i)=>{
    const answered=state.chosen!==null,correct=answered&&q.answer===i,wrong=answered&&state.chosen===i&&!correct;
    const hidden=state.eliminated.includes(i);
    return `<button class="option ${correct?'correct':''} ${wrong?'incorrect':''} ${hidden?'eliminated':''}" data-action="answer" data-i="${i}" ${answered||hidden?'disabled':''}><span class="letter">${LABELS[i]}</span><span class="txt">${escape(o)}</span></button>`;
  }).join('');
  const feedback=q=>{
    if(state.chosen===null)return '';
    const good=state.chosen===q.answer;
    return `<section class="feedback ${good?'good':'bad'}" id="answer-feedback" aria-live="polite"><h3>${good?'✓ إجابة صحيحة':'✕ إجابة غير صحيحة'}</h3><div class="answer-title">الجواب الصحيح: ${LABELS[q.answer]} — ${escape(q.options[q.answer])}</div><div class="body-text">${escape(q.explanation)}</div>${sourceBox(q)}<div class="next-row"><button class="btn primary" data-action="next">${state.session?.mode==='challenge'&&state.session?.lost?'عرض النتيجة':state.session?.mode==='challenge'&&state.session?.step>=15?'إتمام التحدّي':'السؤال التالي'} ⟵</button><button class="btn ghost" data-action="bookmark">${progress.bookmarks.includes(q.id)?'★ إزالة من المحفوظات':'☆ حفظ السؤال'}</button></div></section>`};
  const side=()=>{const s=state.session;return `<aside class="challenge-side"><h3>✦ سلّم التحدّي</h3><div class="challenge-steps">${POINTS.slice().reverse().map((p,i)=>{const n=15-i;return `<div class="challenge-step ${s.step===n?'active':s.step>n?'done':''}"><span>${n}</span><b>${fmt(p)}</b></div>`}).join('')}</div><div class="side-note">إذا أخطأت، يظهر لك التصحيح والدليل قبل إنهاء الجولة. نقاط التحدي رمزية ولا توجد جوائز مالية.</div></aside>`};
  const quiz=()=>{
    const q=state.selected,s=state.session;
    if(!q||!s)return `<div class="empty">لا يوجد سؤال متاح. اختر أقسامًا أخرى من الإعدادات.</div>`;
    let flag=s.mode==='challenge'?`السؤال ${s.step} من 15`:`التعلّم الحر · ${fmt(s.answered+1)}`;
    return `<div class="section-head"><div><h2>${s.mode==='challenge'?'تحدّي المعرفة':'رحلة التعلّم'}</h2><p>اقرأ السؤال بدقة؛ ستظهر الإجابة وشرحها بعد اختيارك.</p></div><button class="btn ghost" data-action="home">الرئيسية</button></div><div class="quiz-layout"><div class="quiz-main"><article class="quiz-card"><div class="quiz-over"><span class="over-pill gold">${escape(choiceCat(q.category))}</span><span class="over-pill">${flag}</span><span class="over-pill">المستوى ${q.difficulty}/5</span><span class="over-pill">${KINDS[q.kind]||'سؤال'}</span></div><div class="question">${escape(q.question)}</div><div class="options">${opts(q)}</div><div class="quiz-controls"><div class="control-group"><button class="tiny-control" data-action="bookmark">${progress.bookmarks.includes(q.id)?'★ محفوظ':'☆ حفظ'}</button><button class="tiny-control" data-action="copy">نسخ السؤال</button></div>${s.mode==='challenge'?`<div class="control-group"><button class="tiny-control" data-action="fifty" ${s.usedFifty||state.chosen!==null?'disabled':''}>٥٠:٥٠</button><button class="tiny-control" data-action="skip" ${s.usedSkip||state.chosen!==null?'disabled':''}>تغيير السؤال</button></div>`:`<div class="control-group"><button class="tiny-control" data-action="skip">تخطّي دون نقاط</button></div>`}</div>${feedback(q)}</article></div>${s.mode==='challenge'?side():''}</div>`;
  };
  const settingsPage=()=>`<h1 class="page-title">الإعدادات</h1><p class="lead">حدد المجالات التي تريدها؛ تطبّق الاختيارات على وضع التعلّم، وعلى ويدجت أندرويد عند تشغيله من التطبيق المثبت.</p><section class="panel"><h2>المجالات التعليمية</h2><p class="lead">اختر مجالًا واحدًا على الأقل. إجمالي الأسئلة في المجالات المختارة: <b id="current-total">${fmt(META.categories.filter(c=>settings.enabled.includes(c.id)).reduce((n,c)=>n+c.count,0))}</b></p><div class="cats-check">${META.categories.map(c=>`<label class="cat-check"><span><b>${escape(c.title)}</b><small>${fmt(c.count)} صيغة سؤال</small></span><input type="checkbox" class="toggle" data-setting="cat" data-cat="${c.id}" ${settings.enabled.includes(c.id)?'checked':''} aria-label="تفعيل ${escape(c.title)}"></label>`).join('')}</div></section><section class="panel"><h2>طريقة الدراسة</h2><div class="setting-row"><div><b>المستوى الأدنى للصعوبة</b><p>تظهر أيضًا الأسئلة الأصعب منه. بعض الأقسام تضم أسئلة متقدمة أصلًا.</p></div><div><span id="diff-num">${settings.minDifficulty}</span> / 5 <input class="range" type="range" min="1" max="5" step="1" data-setting="difficulty" value="${settings.minDifficulty}" aria-label="الصعوبة"></div></div><div class="setting-row"><div><b>إدراج أسئلة المقارنة والتركيب</b><p>تزيد العدد كثيرًا، لكنها قد تعيد اختبار وقائع سبق طرحها بصيغ مختلفة. مُعطّلة افتراضيًا.</p></div><input type="checkbox" class="toggle" data-setting="comparisons" ${settings.comparisons?'checked':''}></div><div class="setting-row"><div><b>تجنب تكرار السؤال نفسه</b><p>يعتمد على ذاكرة الجهاز، وعند استنفاد الخيارات يبدأ دورة جديدة.</p></div><input type="checkbox" class="toggle" data-setting="avoidRepeats" ${settings.avoidRepeats?'checked':''}></div><div class="settings-actions"><button class="btn primary" data-action="start-learn">احفظ وابدأ التعلّم</button><button class="btn secondary" data-action="start-challenge">ابدأ التحدّي</button></div></section><section class="panel"><h2>التقدم والنسخ الاحتياطي</h2><p class="lead">يمكنك تصدير الإحصاءات والإعدادات والمحفوظات ونقلها إلى هاتف آخر.</p><div class="settings-actions"><button class="btn ghost" data-action="export">تصدير بيانات التقدم</button><label class="btn ghost" style="cursor:pointer">استيراد البيانات <input type="file" id="import-file" accept="application/json,.json" hidden></label><button class="btn ghost danger" data-action="reset">مسح التقدم</button></div></section><div class="info-strip">الأسئلة والشروح مضمنة في ملفات المشروع. لا تحتاج إلى حساب أو خادم. الويدجت الأصلية تحتاج تثبيت ملف أندرويد الناتج من GitHub Actions؛ إضافة موقع GitHub Pages للشاشة الرئيسية لا تنشئ ويدجت بأربعة خيارات.</div>`;
  const savedPage=()=>{
    const ids=[...progress.bookmarks].reverse().slice(0,120);
    return `<h1 class="page-title">أسئلتك المحفوظة</h1><p class="lead">يمكنك الرجوع إلى شرح أي سؤال حتى بعد انتهاء التحدّي.</p>${ids.length?`<div class="search-results">${ids.map(id=>BANK.find(q=>q.id===id)).filter(Boolean).map(q=>`<button class="result-item" data-action="open-id" data-id="${escape(q.id)}">${escape(q.question.slice(0,170))}<small>${escape(choiceCat(q.category))} · عرض الشرح</small></button>`).join('')}</div>`:`<div class="empty">لم تحفظ أي سؤال بعد. اضغط ☆ بجانب السؤال لحفظه.</div>`}<div class="section-head"><div><h2>راجع أخطاءك</h2><p>آخر الأسئلة التي لم تكن إجابتك فيها صحيحة.</p></div></div>${progress.mistakes.length?`<div class="search-results">${progress.mistakes.slice(-25).reverse().map(id=>BANK.find(q=>q.id===id)).filter(Boolean).map(q=>`<button class="result-item" data-action="open-id" data-id="${escape(q.id)}">${escape(q.question.slice(0,170))}<small>${escape(choiceCat(q.category))} · تصحيح وشرح</small></button>`).join('')}</div>`:'<div class="empty">لا توجد أخطاء مسجلة بعد.</div>'}`;
  };
  const searchPage=()=>`<h1 class="page-title">ابحث في الأسئلة</h1><p class="lead">ابحث عن النبي أو الصحابي أو المصطلح الذي تريد دراسته. يعرض البحث 40 نتيجة في كل مرة.</p><input id="search-input" class="searchbox" type="search" autocomplete="off" placeholder="مثال: يوسف، الهجرة، القدوس، أحد..." value="${escape(state.search)}" /><div id="search-results">${searchResults()}</div>`;
  const searchResults=()=>{
    const s=state.search.trim().toLowerCase();
    if(!s)return '<div class="empty">اكتب كلمة أو عبارة لتظهر الأسئلة المرتبطة بها.</div>';
    const found=BANK.filter(q=>(q.question+' '+q.options.join(' ')+' '+choiceCat(q.category)).toLowerCase().includes(s)).slice(0,40);
    return found.length?`<div class="search-results">${found.map(q=>`<button class="result-item" data-action="open-id" data-id="${escape(q.id)}">${escape(q.question.slice(0,210))}<small>${escape(choiceCat(q.category))} · ${KINDS[q.kind]||'سؤال'}</small></button>`).join('')}</div>`:'<div class="empty">لم نعثر على نتيجة مطابقة. جرّب كلمة أخرى.</div>';
  };
  const finishPage=()=>{
    let s=state.session||{};
    return `<section class="finished"><div class="trophy">✦</div><span class="eyebrow">اكتمل التحدّي</span><h1>نتيجة جولة المعرفة</h1><strong>${fmt(s.points||0)} نقطة</strong><p>أجبت عن ${fmt(s.answered||0)} من أصل 15 سؤالًا. يمكنك إعادة المحاولة بأسئلة مختلفة، أو التعلّم بحرية دون عقوبة عند الخطأ.</p><div class="actions" style="justify-content:center"><button class="btn primary" data-action="start-challenge">تحدٍّ جديد</button><button class="btn secondary" data-action="start-learn">التعلّم الحر</button></div></section>`;
  };
  function page(){switch(state.view){case 'home':return home();case 'quiz':return quiz();case 'settings':return settingsPage();case 'saved':return savedPage();case 'search':return searchPage();case 'finished':return finishPage();default:return home()}}
  function render(options={}){app.innerHTML=header()+`<main class="wrap main">${page()}</main>`+footer()+tabs();if(!options.keepScroll)window.scrollTo({top:0,behavior:'instant'});}
  function persist(){write(LS_SETTINGS,settings);write(LS_PROGRESS,progress);write(LS_SEEN,seen);write(LS_LAST,lastGroups)}
  function syncAndroid(){try{window.AndroidBridge?.saveCategories?.(JSON.stringify(settings.enabled));window.AndroidBridge?.saveDifficulty?.(String(settings.minDifficulty));window.AndroidBridge?.saveComparisons?.(String(settings.comparisons))}catch(e){console.warn('Android preferences not synced',e)}}
  function available(catFilter=null,mode='learn'){
    let cats=catFilter?[catFilter]:settings.enabled;
    let pool=BANK.filter(q=>cats.includes(q.category)&&q.difficulty>=settings.minDifficulty&&((settings.comparisons)||q.kind!=='comparison'));
    if(!pool.length)pool=BANK.filter(q=>cats.includes(q.category)&&q.kind!=='comparison');
    if(mode==='challenge'&&state.session?.step>=10){const adv=pool.filter(q=>q.difficulty>=4);if(adv.length)pool=adv;}
    return pool;
  }
  function pickQuestion(catFilter=null){
    const pool=available(catFilter,state.session?.mode||'learn');
    if(!pool.length)return null;
    const recent=new Set(lastGroups.slice(-70));
    let items=pool.filter(q=>!recent.has(q.group));
    if(!items.length)items=pool;
    if(settings.avoidRepeats){const unseen=items.filter(q=>!seen.includes(q.id));if(unseen.length)items=unseen;else{seen=[];}}
    // Give every selected category an opportunity rather than over-sampling large categories.
    const allCats=[...new Set(items.map(q=>q.category))];
    const least=Math.min(...allCats.map(id=>state.session?.categoryCounts?.[id]||0));
    const eligible=allCats.filter(id=>(state.session?.categoryCounts?.[id]||0)<=least+1);
    const cat=eligible[Math.floor(Math.random()*eligible.length)];
    const options=items.filter(q=>q.category===cat);
    return options[Math.floor(Math.random()*options.length)]||items[Math.floor(Math.random()*items.length)];
  }
  function start(mode='learn',cat=null,forceQuestion=null){
    state.session={mode,cat,step:1,answered:0,points:0,usedFifty:false,usedSkip:false,lost:false,categoryCounts:{}};
    state.selected=forceQuestion||pickQuestion(cat);
    if(!state.selected){state.view='settings';render();return;}
    state.chosen=null;state.eliminated=[];state.view='quiz';render();
  }
  function next(){
    const s=state.session;
    if(!s)return;
    if(s.mode==='challenge'&&((s.lost)||s.step>=15)){finish();return;}
    if(s.mode==='challenge')s.step++;
    state.selected=pickQuestion(s.cat);
    if(!state.selected){state.view='home';render();return;}
    state.chosen=null;state.eliminated=[];render();
  }
  function finish(){if(state.session){progress.best=Math.max(progress.best,state.session.points);write(LS_PROGRESS,progress)}state.view='finished';render()}
  function answer(i){const q=state.selected,s=state.session;if(!q||state.chosen!==null||state.eliminated.includes(i))return;
    state.chosen=i;s.answered++;s.categoryCounts[q.category]=(s.categoryCounts[q.category]||0)+1;
    const correct=i===q.answer;
    if(s.mode==='challenge'){if(correct)s.points=POINTS[s.step-1];else s.lost=true;}
    progress.total++;progress.correct+=correct?1:0;progress.wrong+=correct?0:1;
    progress.byCat[q.category]??={total:0,correct:0};progress.byCat[q.category].total++;progress.byCat[q.category].correct+=correct?1:0;
    if(!correct){progress.mistakes=[...new Set([...progress.mistakes,q.id])].slice(-1000)}
    progress.history.push({id:q.id,correct,time:Date.now()});progress.history=progress.history.slice(-500);
    if(!seen.includes(q.id))seen.push(q.id);lastGroups.push(q.group||q.id);lastGroups=lastGroups.slice(-120);
    persist();render({keepScroll:true});requestAnimationFrame(()=>document.getElementById('answer-feedback')?.scrollIntoView({behavior:'smooth',block:'start'}));
  }
  function bookmark(){let q=state.selected;if(!q)return;const ix=progress.bookmarks.indexOf(q.id);if(ix>=0)progress.bookmarks.splice(ix,1);else progress.bookmarks.push(q.id);persist();render({keepScroll:true})}
  function copy(){const q=state.selected;if(!q)return;const s=q.question+'\n'+q.options.map((x,i)=>LABELS[i]+') '+x).join('\n');if(navigator.clipboard?.writeText){navigator.clipboard.writeText(s).then(()=>alert('تم نسخ السؤال.')).catch(()=>prompt('انسخ السؤال:',s))}else prompt('انسخ السؤال:',s)}
  function openQ(id){const q=BANK.find(x=>x.id===id);if(!q)return;start('learn',q.category,q)}
  window.openQuestionById=openQ;
  function fifty(){const q=state.selected,s=state.session;if(!q||state.chosen!==null||s.usedFifty)return;s.usedFifty=true;const wrong=[0,1,2,3].filter(i=>i!==q.answer);for(let i=wrong.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[wrong[i],wrong[j]]=[wrong[j],wrong[i]];}state.eliminated=wrong.slice(0,2);render({keepScroll:true})}
  function skip(){const s=state.session;if(!s||state.chosen!==null)return;if(s.mode==='challenge'){if(s.usedSkip)return;s.usedSkip=true;}state.selected=pickQuestion(s.cat);state.eliminated=[];state.chosen=null;render({keepScroll:true})}
  function updateCats(cat,checked){const selected=new Set(settings.enabled);if(checked)selected.add(cat);else selected.delete(cat);if(!selected.size){alert('يجب تفعيل قسم واحد على الأقل.');render({keepScroll:true});return;}settings.enabled=[...selected];persist();syncAndroid();const x=document.getElementById('current-total');if(x)x.textContent=fmt(META.categories.filter(c=>settings.enabled.includes(c.id)).reduce((n,c)=>n+c.count,0));}
  function exportData(){const file=new Blob([JSON.stringify({settings,progress,seen,lastGroups,version:3},null,2)],{type:'application/json'});const url=URL.createObjectURL(file);const a=document.createElement('a');a.href=url;a.download='noor-alilm-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),3000)}
  async function importData(file){try{const obj=JSON.parse(await file.text());if(!obj.settings||!obj.progress)throw Error('ملف غير معروف');settings={...defaultSettings,...obj.settings};settings.enabled=(Array.isArray(settings.enabled)?settings.enabled:defaultSettings.enabled).filter(x=>CAT[x]);if(!settings.enabled.length)settings.enabled=defaultSettings.enabled;progress={...progress,...obj.progress};seen=Array.isArray(obj.seen)?obj.seen:[];lastGroups=Array.isArray(obj.lastGroups)?obj.lastGroups:[];persist();syncAndroid();alert('تم استيراد بيانات التقدم.');render()}catch(e){alert('تعذر استيراد الملف: '+e.message)}}
  function clickAction(a,btn){switch(a){case 'home':state.view='home';render();break;case 'settings':state.view='settings';render();break;case 'saved':state.view='saved';render();break;case 'search':state.view='search';render();break;case 'start-learn':start('learn');break;case 'start-challenge':start('challenge');break;case 'start-cat':start('learn',btn.dataset.cat);break;case 'answer':answer(Number(btn.dataset.i));break;case 'next':next();break;case 'fifty':fifty();break;case 'skip':skip();break;case 'bookmark':bookmark();break;case 'copy':copy();break;case 'open-id':openQ(btn.dataset.id);break;case 'export':exportData();break;case 'reset':if(confirm('سيتم حذف جميع الإحصاءات والمحفوظات من هذا الجهاز. هل أنت متأكد؟')){progress={total:0,correct:0,wrong:0,best:0,byCat:{},bookmarks:[],mistakes:[],history:[]};seen=[];lastGroups=[];persist();render();}break;}}
  app.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(b)clickAction(b.dataset.action,b)});
  app.addEventListener('change',e=>{const t=e.target;const v=t.dataset.setting;if(v==='cat')updateCats(t.dataset.cat,t.checked);if(v==='comparisons'){settings.comparisons=t.checked;persist();syncAndroid();}if(v==='avoidRepeats'){settings.avoidRepeats=t.checked;persist()}if(t.id==='import-file'&&t.files?.[0])importData(t.files[0])});
  app.addEventListener('input',e=>{let t=e.target;if(t.id==='search-input'){state.search=t.value;document.getElementById('search-results').innerHTML=searchResults()}if(t.dataset.setting==='difficulty'){settings.minDifficulty=Number(t.value);document.getElementById('diff-num').textContent=t.value;persist();syncAndroid();}});
  if('serviceWorker' in navigator&&location.protocol==='https:'){navigator.serviceWorker.register('./sw.js').catch(()=>{});}
  syncAndroid();render();
})();

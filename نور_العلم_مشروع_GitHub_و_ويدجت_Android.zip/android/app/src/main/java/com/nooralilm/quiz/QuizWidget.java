package com.nooralilm.quiz;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/** Native, fully interactive home-screen quiz. No web browser is needed for widget actions. */
public class QuizWidget extends AppWidgetProvider {
    private static final String ACT_ANSWER="com.nooralilm.quiz.ANSWER";
    private static final String ACT_NEXT="com.nooralilm.quiz.NEXT";
    private static final String PREF="noor_widget_state";
    private static final int[] CHOICES={R.id.choice0,R.id.choice1,R.id.choice2,R.id.choice3};
    private static final String[] LETTERS={"أ","ب","ج","د"};
    private static JSONArray cachedQuestions;
    private static final Random RANDOM=new Random();

    private static synchronized JSONArray bank(Context context){
        if(cachedQuestions!=null)return cachedQuestions;
        try(InputStream in=context.getAssets().open("questions_widget.json");ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[16384];int n;
            while((n=in.read(buf))!=-1)out.write(buf,0,n);
            cachedQuestions=new JSONArray(out.toString(StandardCharsets.UTF_8.name()));
        }catch(Exception e){cachedQuestions=new JSONArray();}
        return cachedQuestions;
    }
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    private static String stateKey(int id){return "q_"+id;}
    private static String answerKey(int id){return "answer_"+id;}
    private static String recentKey(int id){return "recent_"+id;}
    private static int pick(Context c,int widgetId){
        JSONArray data=bank(c);
        int n=data.length(); if(n==0)return -1;
        String enabled=c.getSharedPreferences("noor_config",Context.MODE_PRIVATE).getString("categories","");
        Set<String> active=new HashSet<>();
        if(enabled!=null&&!enabled.isEmpty())active.addAll(Arrays.asList(enabled.split(",")));
        int minLevel=c.getSharedPreferences("noor_config",Context.MODE_PRIVATE).getInt("difficulty",3);
        String history=prefs(c).getString(recentKey(widgetId),"");
        Set<String> recent=new HashSet<>(Arrays.asList(history.split(",")));
        ArrayList<Integer> possible=new ArrayList<>(),fallback=new ArrayList<>();
        for(int i=0;i<n;i++){
            JSONObject q=data.optJSONObject(i);if(q==null)continue;
            if(!active.isEmpty()&&!active.contains(q.optString("c")))continue;
            fallback.add(i);
            if(q.optInt("difficulty",3)<minLevel)continue;
            if(!recent.contains(q.optString("id")))possible.add(i);
        }
        if(possible.isEmpty())possible=fallback;
        if(possible.isEmpty()){
            for(int i=0;i<n;i++)possible.add(i);
        }
        return possible.get(RANDOM.nextInt(possible.size()));
    }
    private static void remember(Context c,int id,String qid){
        String old=prefs(c).getString(recentKey(id),"");
        ArrayList<String> recent=new ArrayList<>();
        if(old!=null&&!old.isEmpty())recent.addAll(Arrays.asList(old.split(",")));
        recent.remove(qid); recent.add(qid);
        while(recent.size()>65)recent.remove(0);
        prefs(c).edit().putString(recentKey(id),android.text.TextUtils.join(",",recent)).apply();
    }
    private static JSONObject get(Context c,int idx){return bank(c).optJSONObject(idx);}
    private static PendingIntent broadcast(Context c,int id,String action,int choice){
        Intent intent=new Intent(c,QuizWidget.class);
        intent.setAction(action);
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
        intent.putExtra("choice",choice);
        intent.setData(Uri.parse("noorquiz://widget/"+id+"/"+action+"/"+choice));
        return PendingIntent.getBroadcast(c,id*10+choice,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent fullExplain(Context c,int widgetId,String questionId){
        Intent intent=new Intent(c,MainActivity.class);
        intent.setAction(Intent.ACTION_MAIN);
        intent.putExtra(MainActivity.EXTRA_QUESTION_ID,questionId);
        intent.setData(Uri.parse("noorquiz://open/"+widgetId+"/"+questionId));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c,widgetId*17+1,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void update(Context c,AppWidgetManager mgr,int id){
        SharedPreferences p=prefs(c);
        int idx=p.getInt(stateKey(id),-1);
        JSONObject q=get(c,idx);
        if(q==null){idx=pick(c,id);q=get(c,idx);p.edit().putInt(stateKey(id),idx).putInt(answerKey(id),-1).apply();if(q!=null)remember(c,id,q.optString("id"));}
        RemoteViews views=new RemoteViews(c.getPackageName(),R.layout.widget_quiz);
        if(q==null){
            views.setTextViewText(R.id.widget_question,"تعذّر تحميل الأسئلة. افتح التطبيق ثم جرّب مجددًا.");
            mgr.updateAppWidget(id,views);return;
        }
        String question=q.optString("q","سؤال جديد").replace("\n"," ");
        views.setTextViewText(R.id.widget_question,question);
        JSONArray options=q.optJSONArray("o");
        int selected=p.getInt(answerKey(id),-1);
        int correct=q.optInt("a",0);
        for(int i=0;i<4;i++){
            String op=options!=null?options.optString(i,""):"";
            views.setTextViewText(CHOICES[i],LETTERS[i]+". "+op);
            views.setViewVisibility(CHOICES[i],selected>=0?View.GONE:View.VISIBLE);
            views.setOnClickPendingIntent(CHOICES[i],broadcast(c,id,ACT_ANSWER,i));
            views.setInt(CHOICES[i],"setBackgroundResource",selected>=0&&i==correct?R.drawable.widget_correct:(selected==i&&selected!=correct?R.drawable.widget_wrong:R.drawable.widget_choice));
        }
        if(selected<0){
            views.setViewVisibility(R.id.widget_feedback,View.GONE);
            views.setTextViewText(R.id.widget_next,"سؤال آخر ↻");
        }else{
            String correctOption=options!=null?options.optString(correct,""):"";
            String head=(selected==correct?"✓ إجابة صحيحة. ":"✕ الصحيح: "+LETTERS[correct]+". "+correctOption+". ");
            String why=q.optString("why","");
            if(why.length()>210)why=why.substring(0,207)+"…";
            String ref=q.optString("ref","");
            if(ref.length()>65)ref=ref.substring(0,62)+"…";
            views.setTextViewText(R.id.widget_feedback,head+why+"\nالمصدر: "+ref);
            views.setViewVisibility(R.id.widget_feedback,View.VISIBLE);
            views.setTextViewText(R.id.widget_next,"السؤال التالي ←");
        }
        views.setOnClickPendingIntent(R.id.widget_next,broadcast(c,id,ACT_NEXT,9));
        views.setOnClickPendingIntent(R.id.widget_full,fullExplain(c,id,q.optString("id")));
        mgr.updateAppWidget(id,views);
    }
    public static void refreshAll(Context c){
        AppWidgetManager mgr=AppWidgetManager.getInstance(c);
        int[] ids=mgr.getAppWidgetIds(new ComponentName(c,QuizWidget.class));
        for(int id:ids)update(c,mgr,id);
    }
    @Override public void onUpdate(Context c,AppWidgetManager mgr,int[] ids){
        for(int id:ids)update(c,mgr,id);
    }
    @Override public void onReceive(Context c,Intent intent){
        super.onReceive(c,intent);
        String action=intent.getAction();
        if(!ACT_ANSWER.equals(action)&&!ACT_NEXT.equals(action))return;
        int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
        if(id==AppWidgetManager.INVALID_APPWIDGET_ID)return;
        SharedPreferences p=prefs(c);
        if(ACT_ANSWER.equals(action)){
            if(p.getInt(answerKey(id),-1)<0){
                p.edit().putInt(answerKey(id),intent.getIntExtra("choice",-1)).apply();
            }
        }else{
            int idx=pick(c,id);
            JSONObject q=get(c,idx);
            if(q!=null)remember(c,id,q.optString("id"));
            p.edit().putInt(stateKey(id),idx).putInt(answerKey(id),-1).apply();
        }
        update(c,AppWidgetManager.getInstance(c),id);
    }
    @Override public void onDeleted(Context c,int[] ids){
        SharedPreferences.Editor e=prefs(c).edit();
        for(int id:ids){e.remove(stateKey(id)).remove(answerKey(id)).remove(recentKey(id));}
        e.apply();
        super.onDeleted(c,ids);
    }
}

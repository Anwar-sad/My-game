package com.nooralilm.quiz;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    public static final String EXTRA_QUESTION_ID = "question_id";
    private WebView webView;
    private boolean pageReady = false;
    private String waitingQuestion = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(6, 19, 26));
        getWindow().setNavigationBarColor(Color.rgb(6, 19, 26));
        webView = new WebView(this);
        FrameLayout root=new FrameLayout(this);
        root.addView(webView,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.setBackgroundColor(Color.rgb(6, 19, 26));
        webView.addJavascriptInterface(new Bridge(),"AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view,String url) {
                pageReady=true;openPendingQuestion();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                Uri url=request.getUrl();
                if("file".equals(url.getScheme()))return false;
                if("http".equals(url.getScheme())||"https".equals(url.getScheme())){
                    startActivity(new Intent(Intent.ACTION_VIEW,url));return true;
                }
                return false;
            }
        });
        if(getIntent()!=null)waitingQuestion=getIntent().getStringExtra(EXTRA_QUESTION_ID);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        waitingQuestion=intent.getStringExtra(EXTRA_QUESTION_ID);
        openPendingQuestion();
    }
    private void openPendingQuestion(){
        if(!pageReady||waitingQuestion==null||webView==null)return;
        final String id=waitingQuestion;
        waitingQuestion=null;
        webView.evaluateJavascript("window.openQuestionById&&window.openQuestionById("+JSONObject.quote(id)+")",null);
    }
    @Override public void onBackPressed(){
        if(webView!=null&&webView.canGoBack())webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        if(webView!=null){webView.removeJavascriptInterface("AndroidBridge");webView.destroy();webView=null;}
        super.onDestroy();
    }
    public class Bridge {
        @JavascriptInterface public void saveCategories(String json){
            try{
                JSONArray arr=new JSONArray(json);
                StringBuilder result=new StringBuilder();
                for(int i=0;i<arr.length();i++){
                    if(i>0)result.append(',');
                    result.append(arr.getString(i));
                }
                getSharedPreferences("noor_config",MODE_PRIVATE).edit().putString("categories",result.toString()).apply();
                new Handler(Looper.getMainLooper()).post(()->QuizWidget.refreshAll(MainActivity.this));
            }catch(Exception ignored){}
        }
        @JavascriptInterface public void saveDifficulty(String val){
            try{getSharedPreferences("noor_config",MODE_PRIVATE).edit().putInt("difficulty",Integer.parseInt(val)).apply();}
            catch(Exception ignored){}
        }
        @JavascriptInterface public void saveComparisons(String val){
            getSharedPreferences("noor_config",MODE_PRIVATE).edit().putBoolean("comparisons",Boolean.parseBoolean(val)).apply();
        }
    }
}

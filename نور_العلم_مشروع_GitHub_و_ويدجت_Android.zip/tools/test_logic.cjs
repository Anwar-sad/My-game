const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const ROOT=path.resolve(__dirname,'..');
const listeners={};const saved=new Map();
const app={innerHTML:'',addEventListener:(a,fn)=>listeners[a]=fn};
const window={scrollTo:()=>{},AndroidBridge:{saveCategories:()=>{},saveDifficulty:()=>{},saveComparisons:()=>{}}};
const document={getElementById:id=>id==='app'?app:{scrollIntoView:()=>{},set textContent(t){this._text=t},get textContent(){return this._text},innerHTML:''}};
const context={window,document,console,navigator:{},location:{protocol:'file:'},localStorage:{getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v)},Math,Date,JSON,Array,Set,Map,URL,Blob,alert:()=>{},confirm:()=>true,prompt:()=>null,requestAnimationFrame:fn=>fn()};
vm.createContext(context);
for(const name of ['questions.js','app.js']){
 const p=path.join(ROOT,'docs',name);vm.runInContext(fs.readFileSync(p,'utf8'),context,{filename:name,timeout:20000});
}
assert(window.NOOR_META.total===5731);
assert(app.innerHTML.includes('نور العلم')&&app.innerHTML.includes('الأنبياء والرسل'));
const fire=(action,x={})=>listeners.click({target:{closest:()=>({dataset:{action,...x}})}});
fire('start-learn');assert(app.innerHTML.includes('class="question"'));assert((app.innerHTML.match(/class="option /g)||[]).length===4);
fire('answer',{i:'0'});assert(app.innerHTML.includes('class="feedback'));
fire('next');assert(app.innerHTML.includes('class="question"'));
fire('settings');assert(app.innerHTML.includes('المستوى الأدنى للصعوبة'));
fire('saved');assert(app.innerHTML.includes('أسئلتك المحفوظة'));
fire('home');assert(app.innerHTML.includes('رحلة في المعرفة الإسلامية'));
fire('start-challenge');assert(app.innerHTML.includes('سلّم التحدّي'));
fire('fifty');assert(app.innerHTML.includes('eliminated'));
window.openQuestionById('Nnames0000a');assert(app.innerHTML.includes('class="question"'));
console.log('All web app logic tests PASSED. Total questions:',window.NOOR_META.total,'categories:',window.NOOR_META.categories.map(c=>c.count));
